from .AutoEIS import *


__version__ = "0.0.15"
__description__ = "A demo package to assist EIS analysis by automatically proposing statistically plausible ECM "
__author__ = "Runze Zhang, Robert Black, Jason Hattrick-Simpers"
__contact_information = "runzee.zhang@mail.utoronto.ca"
